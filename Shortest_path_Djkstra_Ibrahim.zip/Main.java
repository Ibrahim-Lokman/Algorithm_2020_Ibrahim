import java.util.ArrayList;
import java.io.*;
import java.util.*;

class Main {  

  public static void main(String args[]) throws Exception
   { 
     File f = new File("input.txt"); 
     Scanner sc = new Scanner(f);

     int node = sc.nextInt(), edge = sc.nextInt(), khicuNa = sc.nextInt(), testCase = sc.nextInt();
     int [][] twoD = new int[node+1][node+1];
   
     for(int c = 0 ; c < edge ; ++c )
        {
           int m = sc.nextInt(), n = sc.nextInt(), w = sc.nextInt();
           twoD[m][n] = w;
        }

     for(int i = 0 ; i < testCase ; i++)
       { 
          int source = sc.nextInt(), gontobbo = sc.nextInt();
          Main NewObject = new Main(); 
          NewObject.dijkstra(twoD, node, source, gontobbo); 
       }
     } 

  void dijkstra(int g[][], int node ,int src, int gontobbo) 
    {   
        int dis[] = new int[node+1];
        Boolean sptSet[] = new Boolean[node+1]; 
        for (int i = 0; i < node+1; i++) { 
            dis[i] = Integer.MAX_VALUE; 
            sptSet[i] = false; 
        } 
        dis[src] = 0; 
        for (int count = 0; count < node; count++) { 
            int u = minDistance(dis, sptSet, node+1); 
            sptSet[u] = true; 
            for (int v = 0; v < node+1; v++) 
                if (!sptSet[v] && g[u][v] != 0 &&  
                   dis[u] != Integer.MAX_VALUE && dis[u] + g[u][v] < dis[v]) 
                    dis[v] = dis[u] + g[u][v]; 
        } 
        if(dis[gontobbo]  >= Integer.MAX_VALUE)
          System.out.println("Path not found for "+src+" to "+gontobbo);
        else
         System.out.println("Distance from "+src+" to "+gontobbo+" is "+ dis[gontobbo]);
    }

 
    int minDistance(int dist[], Boolean sptSet[], int Vertex) 
    { 
        int min = Integer.MAX_VALUE;
        int min_index = -1; 
        for (int v = 0; v < Vertex; v++) 
            if (sptSet[v] == false && dist[v] <= min) { 
                min = dist[v]; 
                min_index = v; 
            } 
  
        return min_index; 
    }  
  
}